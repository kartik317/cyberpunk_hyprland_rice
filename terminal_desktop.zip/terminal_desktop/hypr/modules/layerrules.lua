hl.layer_rule({ match = { namespace = "swaync-control-center" }, blur = true })
hl.layer_rule({ match = { namespace = "swaync-notification-window" }, blur = true })
hl.layer_rule({ match = { namespace = "swaync-control-center" }, ignore_alpha = 0.0 })
hl.layer_rule({ match = { namespace = "swaync-notification-window" }, ignore_alpha = 0.0 })

hl.layer_rule({ match = { namespace = "swaync-control-center" },       animation = "slide right" })
hl.layer_rule({ match = { namespace = "swaync-notification-window" },  animation = "slide right" })

hl.layer_rule({ match = { namespace = "rofi" },                        animation = "slide" })
hl.layer_rule({ match = { namespace = "wofi" },                        animation = "slide" })
hl.layer_rule({ match = { namespace = "logout_dialog" },               animation = "slide" })

hl.layer_rule({
    match = { namespace = "mpvpaper" },
    animation = "fade"
})

hl.layer_rule({
    match = { namespace = "hyprpaper" },
    animation = "fade"
})

hl.layer_rule({
    match = { namespace = "waybar" },
    animation = "fade"
})

hl.layer_rule({
    match = { namespace = "clock-widget" },
    blur = true,
    ignore_alpha = 0
})

hl.layer_rule({
    match = { namespace = "bar" },
    blur = true,
    ignore_alpha = 0
})

hl.layer_rule({
    match = { namespace = "app-launcher" },
    blur = true,
    ignore_alpha = 0
})

hl.layer_rule({
    match = { namespace = "powermenu" },
    blur = true,
    ignore_alpha = 0
})

hl.layer_rule({
    match = { namespace = "wallpaper-switcher" },
    blur = true,
    ignore_alpha = 0
})

hl.layer_rule({
    match = { namespace = "liveWallpaper-switcher" },
    blur = true,
    ignore_alpha = 0
})

hl.layer_rule({
    match = { namespace = "qs-clipboard" },
    blur = true,
    ignore_alpha = 0
})


hl.layer_rule({
    match = { namespace = "qs-tray" },
    blur = true,
    ignore_alpha = 0
})


hl.layer_rule({
    match = { namespace = "notificationcenter" },
    blur = true,
    ignore_alpha = 0
})


hl.layer_rule({
    match = { namespace = "notificationtoast" },
    blur = true,
    ignore_alpha = 0
})
